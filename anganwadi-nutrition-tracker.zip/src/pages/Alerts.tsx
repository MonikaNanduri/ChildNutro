import { useEffect, useState } from 'react';
import { AlertCircle, ArrowRight, Phone } from 'lucide-react';
import { Card, Button } from '../components/ui/Common';
import { api } from '../lib/api';
import { Child } from '../types';

export const Alerts = () => {
  const [children, setChildren] = useState<Child[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.getChildren().then(setChildren).finally(() => setLoading(false));
  }, []);

  const severeCases = children.filter(c => c.status === 'Severe');

  return (
    <div className="space-y-6">
      <div className="bg-red-50 border-l-4 border-red-500 p-6 rounded-2xl">
        <div className="flex items-center gap-4">
          <AlertCircle className="w-8 h-8 text-red-500" />
          <div>
            <h3 className="text-xl font-bold text-red-700">Immediate Attention Required</h3>
            <p className="text-red-600">The following children have been identified with severe malnutrition and need urgent intervention.</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {loading ? (
          <p className="text-gray-400">Loading alerts...</p>
        ) : severeCases.length === 0 ? (
          <Card className="col-span-2 p-12 text-center">
            <div className="w-16 h-16 bg-green-100 text-green-500 rounded-full flex items-center justify-center mx-auto mb-4">
              <AlertCircle className="w-8 h-8" />
            </div>
            <h4 className="text-xl font-bold">No High Priority Alerts</h4>
            <p className="text-gray-500">All tracked children are currently stable. Keep up the good work!</p>
          </Card>
        ) : (
          severeCases.map((child, i) => (
            <Card key={i} className="border-red-100 hover:shadow-md transition-all">
              <div className="flex justify-between items-start mb-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-red-100 rounded-2xl flex items-center justify-center text-red-500 font-bold border border-red-200">
                    !
                  </div>
                  <div>
                    <h4 className="text-lg font-bold">{child.name}</h4>
                    <p className="text-gray-500 text-sm">Age: {child.age} yrs • BMI: {child.bmi}</p>
                  </div>
                </div>
                <span className="px-3 py-1 bg-red-100 text-red-600 rounded-full text-xs font-bold border border-red-200 uppercase tracking-wider">
                  Severe
                </span>
              </div>

              <div className="space-y-3 mb-6 p-4 bg-gray-50 rounded-xl">
                 <div className="flex items-center gap-3 text-sm text-gray-600">
                    <Phone className="w-4 h-4" />
                    <span>Parent: {child.parent_name || 'N/A'} ({child.contact || 'No Contact'})</span>
                 </div>
                 <p className="text-sm font-medium text-gray-700">Action: Provide protein-rich supplements and schedule a primary health center visit.</p>
              </div>

              <div className="flex gap-3">
                 <Button className="flex-1 text-sm py-2">Contact Parent</Button>
                 <Button variant="outline" className="flex-1 text-sm py-2 group">
                    Full Details
                    <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
                 </Button>
              </div>
            </Card>
          ))
        )}
      </div>
    </div>
  );
};
