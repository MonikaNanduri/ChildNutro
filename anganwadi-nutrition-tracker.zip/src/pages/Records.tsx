import { useEffect, useState } from 'react';
import { Search, Filter, Download, ExternalLink, RefreshCw } from 'lucide-react';
import { Card, Input, Button } from '../components/ui/Common';
import { api } from '../lib/api';
import { offlineDb } from '../lib/offlineDb';
import { Child } from '../types';

export const Records = () => {
  const [children, setChildren] = useState<Child[]>([]);
  const [pending, setPending] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('All');

  const fetchData = async () => {
    try {
      const result = await api.getChildren();
      setChildren(result);
      
      const pendingReqs = await offlineDb.getAllRequests();
      const childReqs = pendingReqs.filter(r => r.type === 'fullChildRecord' || r.type === 'addChild');
      setPending(childReqs);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
    window.addEventListener('syncComplete', fetchData);
    return () => window.removeEventListener('syncComplete', fetchData);
  }, []);

  const allRecords = [
    ...pending.map(p => ({
      id: -1, // Temporary
      name: p.type === 'fullChildRecord' ? p.data.childData.name : p.data.name,
      parent_name: p.type === 'fullChildRecord' ? p.data.childData.parent_name : p.data.parent_name,
      height: p.type === 'fullChildRecord' ? p.data.nutritionData.height : p.data.height,
      weight: p.type === 'fullChildRecord' ? p.data.nutritionData.weight : p.data.weight,
      bmi: p.type === 'fullChildRecord' ? p.data.nutritionData.bmi : p.data.bmi,
      status: p.type === 'fullChildRecord' ? p.data.nutritionData.status : p.data.status,
      recorded_at: p.timestamp,
      age: p.type === 'fullChildRecord' ? p.data.childData.age : p.data.age,
      isPending: true
    })),
    ...children
  ];

  const filtered = allRecords.filter(c => {
    const matchesSearch = c.name.toLowerCase().includes(search.toLowerCase()) || 
                         c.parent_name?.toLowerCase().includes(search.toLowerCase());
    const matchesFilter = filter === 'All' || c.status === filter;
    return matchesSearch && matchesFilter;
  });

  const exportCSV = () => {
    const headers = ['Name', 'Age', 'Height', 'Weight', 'BMI', 'Status', 'Date'];
    const rows = filtered.map(c => [
      c.name, c.age, c.height, c.weight, c.bmi, c.status, 
      c.recorded_at ? new Date(c.recorded_at).toLocaleDateString() : ''
    ]);
    const csvContent = "data:text/csv;charset=utf-8," 
      + [headers, ...rows].map(e => e.join(",")).join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `anganwadi_records_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row gap-4 justify-between items-end md:items-center">
        <div className="flex-1 w-full max-w-md">
          <Input 
            placeholder="Search by name or parent..." 
            icon={Search} 
            value={search}
            onChange={(e: any) => setSearch(e.target.value)}
          />
        </div>
        <div className="flex gap-3 w-full md:w-auto">
          <div className="relative inline-block text-left w-full md:w-auto">
             <select 
               className="h-14 pl-4 pr-10 bg-white border border-gray-200 rounded-xl outline-none focus:ring-2 focus:ring-[#A0C4FF] appearance-none cursor-pointer w-full"
               value={filter}
               onChange={(e) => setFilter(e.target.value)}
             >
                <option value="All">All Status</option>
                <option value="Normal">Normal 😊</option>
                <option value="Underweight">Underweight 😟</option>
                <option value="Overweight">Overweight ⚠️</option>
             </select>
             <Filter className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400 pointer-events-none" />
          </div>
          <Button variant="outline" className="h-14 px-4" onClick={exportCSV}>
            <Download className="w-5 h-5" />
          </Button>
        </div>
      </div>

      <Card className="p-0 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="text-left text-gray-500 bg-gray-50/50 border-b border-gray-100 uppercase text-xs tracking-wider">
                <th className="px-8 py-5 font-semibold">Child Details</th>
                <th className="px-8 py-5 font-semibold">Measurements</th>
                <th className="px-8 py-5 font-semibold">Nutrition Status</th>
                <th className="px-8 py-5 font-semibold">Last Checked</th>
                <th className="px-8 py-5 font-semibold"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {loading ? (
                <tr>
                   <td colSpan={5} className="text-center py-20 text-gray-400">Loading records...</td>
                </tr>
              ) : filtered.length === 0 ? (
                <tr>
                   <td colSpan={5} className="text-center py-20 text-gray-400">No records found matching your search.</td>
                </tr>
              ) : (
                filtered.map((child, i) => (
                  <tr key={i} className="hover:bg-blue-50/30 transition-colors group">
                    <td className="px-8 py-5">
                      <div className="flex items-center gap-4">
                        <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-gray-50 to-gray-200 p-0.5 shadow-sm group-hover:shadow-md transition-all relative">
                          <div className="w-full h-full rounded-[14px] bg-white flex items-center justify-center overflow-hidden">
                             <img 
                              src={`https://api.dicebear.com/7.x/avataaars/svg?seed=child_${child.id}`} 
                              alt={child.name} 
                              className="w-full h-full object-cover scale-110"
                             />
                          </div>
                          {(child as any).isPending && (
                            <div className="absolute -top-1 -right-1 w-5 h-5 bg-trust-blue text-white rounded-full flex items-center justify-center shadow-md animate-pulse">
                              <RefreshCw className="w-3 h-3" />
                            </div>
                          )}
                        </div>
                        <div>
                          <p className="font-bold text-dark-text text-lg tracking-tight flex items-center gap-2">
                             {child.name}
                             {(child as any).isPending && (
                               <span className="text-[8px] font-extrabold px-1.5 py-0.5 bg-trust-blue/10 text-trust-blue rounded uppercase tracking-widest border border-trust-blue/20">
                                 Pending
                               </span>
                             )}
                          </p>
                          <p className="text-gray-400 text-xs font-bold uppercase tracking-wider">Parent: {child.parent_name || 'N/A'}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-8 py-5">
                       <div className="flex gap-4">
                          <div>
                            <p className="text-xs text-gray-400 uppercase font-medium">Height</p>
                            <p className="font-semibold">{child.height || '--'} cm</p>
                          </div>
                          <div className="w-px h-8 bg-gray-100 self-center"></div>
                          <div>
                            <p className="text-xs text-gray-400 uppercase font-medium">Weight</p>
                            <p className="font-semibold">{child.weight || '--'} kg</p>
                          </div>
                       </div>
                    </td>
                    <td className="px-8 py-5">
                      <div className="flex flex-col gap-1">
                        <span className={`w-fit px-3 py-1 rounded-full text-xs font-bold border ${
                          child.status === 'Normal' ? 'bg-green-50 border-green-200 text-green-600' :
                          child.status === 'Underweight' ? 'bg-yellow-50 border-yellow-200 text-yellow-600' :
                          'bg-red-50 border-red-200 text-red-600'
                        }`}>
                          {child.status || 'N/A'}
                        </span>
                        <p className="text-xs text-gray-400 font-medium">BMI: {child.bmi || '--'}</p>
                      </div>
                    </td>
                    <td className="px-8 py-5">
                      <p className="text-gray-600 font-medium">{child.recorded_at ? new Date(child.recorded_at).toLocaleDateString() : 'Never'}</p>
                    </td>
                    <td className="px-8 py-5 text-right">
                      <button className="p-2 text-gray-400 hover:text-blue-500 hover:bg-white rounded-lg transition-all opacity-0 group-hover:opacity-100">
                        <ExternalLink className="w-5 h-5" />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
};
