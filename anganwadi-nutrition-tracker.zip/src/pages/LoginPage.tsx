import React, { useState } from 'react';
import { User, Lock, ArrowRight } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Button, Input, Card } from '../components/ui/Common';
import { api } from '../lib/api';

export const LoginPage = ({ onLogin }: { onLogin: (data: any) => void }) => {
  const [isRegister, setIsRegister] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [formData, setFormData] = useState({ username: '', password: '', name: '' });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      if (isRegister) {
        await api.register(formData);
        setIsRegister(false);
        setError('Registration successful! Please login.');
      } else {
        const res = await api.login(formData.username, formData.password);
        onLogin(res);
      }
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 md:p-8 bg-gradient-to-br from-[#A8E6CF]/40 via-white to-[#A0C4FF]/40">
      <div className="max-w-6xl w-full grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-16 items-center">
        {/* Left: Illustration & Info */}
        <motion.div
           initial={{ opacity: 0, x: -30 }}
           animate={{ opacity: 1, x: 0 }}
           transition={{ duration: 0.8, ease: "easeOut" }}
           className="hidden lg:block space-y-12"
        >
          <div className="space-y-6">
            <motion.div 
               initial={{ opacity: 0, y: 10 }}
               animate={{ opacity: 1, y: 0 }}
               transition={{ delay: 0.3 }}
               className="inline-flex items-center gap-2 px-4 py-2 bg-white/60 backdrop-blur-sm rounded-full border border-white/40 shadow-sm"
            >
              <span className="w-2 h-2 rounded-full bg-health-green animate-pulse"></span>
              <span className="text-[10px] font-extrabold uppercase tracking-[0.2em] text-dark-text/60">Official Anganwadi Portal</span>
            </motion.div>
            
            <h1 className="text-6xl font-extrabold text-[#2D3436] leading-[1.1] tracking-tight">
              Tracking child nutrition for a <span className="text-transparent bg-clip-text bg-gradient-to-r from-health-green to-trust-blue italic">healthier tomorrow</span>
            </h1>
            <p className="text-xl text-gray-500 font-medium leading-relaxed max-w-lg">
              Empowering field workers with data-driven tools to combat malnutrition and ensure every child reaches their full potential.
            </p>
          </div>
          
          <div className="relative group">
            <div className="absolute -inset-4 bg-gradient-to-r from-health-green/20 to-trust-blue/20 rounded-[50px] blur-2xl group-hover:opacity-100 transition-opacity opacity-50"></div>
            <img 
              src="https://images.unsplash.com/photo-1594608661623-aa0bd3a67d28?q=80&w=2000&auto=format&fit=crop" 
              alt="Healthy growing children" 
              className="relative rounded-[48px] shadow-3xl brightness-105 border-8 border-white/40 transition-transform duration-700 group-hover:scale-[1.02]"
            />
          </div>
        </motion.div>

        {/* Right: Login Form */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="flex justify-center"
        >
          <Card className="p-10 md:p-12 border-white/60 shadow-2xl glass-effect rounded-[48px] w-full max-w-md relative overflow-hidden group">
            {/* Subtle light highlight */}
            <div className="absolute -top-24 -right-24 w-48 h-48 bg-trust-blue/20 rounded-full blur-3xl transition-transform duration-1000 group-hover:translate-x-10"></div>
            
            <div className="mb-10 flex justify-between items-start relative z-10">
              <div>
                <h2 className="text-4xl font-extrabold tracking-tight text-dark-text">{isRegister ? 'Join Us' : 'Welcome'}</h2>
                <p className="text-gray-400 font-bold uppercase text-[10px] tracking-[0.15em] mt-2 opacity-80">
                  {isRegister ? 'Create worker profile' : 'Nutrition Dashboard Login'}
                </p>
              </div>
              <div className="w-16 h-16 bg-gradient-to-tr from-health-green/20 to-trust-blue/20 rounded-3xl flex items-center justify-center text-3xl shadow-inner-white">👶</div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-7 relative z-10">
              <AnimatePresence mode="wait">
                {isRegister && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                  >
                    <Input
                      label="Full Name"
                      placeholder="e.g. Meera Devi"
                      icon={User}
                      value={formData.name}
                      onChange={(e: any) => setFormData({ ...formData, name: e.target.value })}
                      required
                    />
                  </motion.div>
                )}
              </AnimatePresence>
              
              <Input
                label="Worker ID / Username"
                placeholder="Enter username"
                icon={User}
                value={formData.username}
                onChange={(e: any) => setFormData({ ...formData, username: e.target.value })}
                required
              />
              <Input
                label="Security Key"
                type="password"
                placeholder="••••••••"
                icon={Lock}
                value={formData.password}
                onChange={(e: any) => setFormData({ ...formData, password: e.target.value })}
                required
              />

              {error && (
                <motion.div 
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="p-4 rounded-xl bg-red-50 border border-red-100 flex items-center gap-3"
                >
                  <div className="w-2 h-2 rounded-full bg-red-500"></div>
                  <p className="text-red-500 text-xs font-bold uppercase tracking-tight">{error}</p>
                </motion.div>
              )}

              <Button type="submit" className="w-full h-16 text-lg rounded-2xl group shadow-lg hover:shadow-trust-blue/25" disabled={loading}>
                {loading ? 'Authenticating...' : (isRegister ? 'Register' : 'Login Now')}
                <ArrowRight className="w-5 h-5 ml-2 transition-transform group-hover:translate-x-1" />
              </Button>
            </form>

            <div className="mt-10 pt-8 border-t border-dark-text/5 text-center relative z-10">
              <p className="text-gray-400 font-medium text-sm">
                {isRegister ? 'Already an agent?' : "New worker?"}
                <button
                  type="button"
                  onClick={() => setIsRegister(!isRegister)}
                  className="text-trust-blue font-bold ml-2 hover:underline tracking-tight"
                >
                  {isRegister ? 'Sign In' : 'Register Here'}
                </button>
              </p>
            </div>
          </Card>
        </motion.div>
      </div>
    </div>
  );
};
