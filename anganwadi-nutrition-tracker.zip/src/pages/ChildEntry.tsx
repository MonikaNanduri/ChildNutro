import React, { useState } from 'react';
import { User, Ruler, Weight, CheckCircle, Calculator, Mic, AlertCircle, Phone, ArrowLeft, Send } from 'lucide-react';
import { Button, Input, Card } from '../components/ui/Common';
import { ProfileImageUpload } from '../components/ui/ProfileImageUpload';
import { api } from '../lib/api';
import { calculateBMI, checkHealthStatus, BMI_CATEGORIES } from '../constants';
import { motion, AnimatePresence } from 'motion/react';

export const ChildEntry = () => {
  const [formData, setFormData] = useState({ 
    name: '', age: '', height: '', weight: '', gender: 'Male', parent_name: '', contact: '', avatar_url: '' 
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [result, setResult] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const validate = () => {
    const newErrors: Record<string, string> = {};
    if (!formData.name) newErrors.name = 'This field is required ⚠️';
    
    const age = parseInt(formData.age);
    if (!formData.age) newErrors.age = 'This field is required ⚠️';
    else if (isNaN(age) || age < 2 || age > 12) newErrors.age = 'Enter valid age (2–12)';

    const height = parseFloat(formData.height);
    if (!formData.height) newErrors.height = 'This field is required ⚠️';
    else if (isNaN(height) || height <= 0) newErrors.height = 'Enter valid height';

    const weight = parseFloat(formData.weight);
    if (!formData.weight) newErrors.weight = 'This field is required ⚠️';
    else if (isNaN(weight) || weight <= 0) newErrors.weight = 'Enter valid weight';

    if (!formData.parent_name) newErrors.parent_name = 'This field is required ⚠️';
    
    if (!formData.contact) newErrors.contact = 'This field is required ⚠️';
    else if (!/^\d{10}$/.test(formData.contact)) newErrors.contact = 'Enter valid mobile number';

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const calculateHealth = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    const h = parseFloat(formData.height);
    const w = parseFloat(formData.weight);
    const age = parseInt(formData.age);

    const bmi = calculateBMI(w, h);
    const { status, heightWarning } = checkHealthStatus(age, formData.gender, h, w);
    setResult({ bmi, status, heightWarning });
  };

  const saveRecord = async () => {
    if (!result) return;
    setLoading(true);
    try {
      await api.saveFullChildRecord(formData, {
        height: parseFloat(formData.height),
        weight: parseFloat(formData.weight),
        bmi: result.bmi,
        status: result.status
      });
      setSubmitted(true);
      // Wait bit then reset
      setTimeout(() => {
        setFormData({ name: '', age: '', height: '', weight: '', gender: 'Male', parent_name: '', contact: '', avatar_url: '' });
        setResult(null);
        setSubmitted(false);
      }, 3000);
    } catch (err) {
      alert('Failed to save record');
    } finally {
      setLoading(false);
    }
  };

  const categoryData = result ? (BMI_CATEGORIES as any)[result.status.toUpperCase()] : null;

  return (
    <div className="relative">
      <AnimatePresence>
        {submitted && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex items-center justify-center bg-health-green/20 backdrop-blur-md p-6"
          >
            <motion.div 
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              className="bg-white p-12 rounded-[48px] shadow-3xl text-center max-w-sm w-full border border-health-green/30"
            >
              <div className="w-24 h-24 bg-health-green/20 rounded-full flex items-center justify-center text-5xl mx-auto mb-6 animate-bounce">
                ✅
              </div>
              <h3 className="text-3xl font-extrabold text-dark-text mb-4">Success!</h3>
              <p className="text-gray-500 font-bold uppercase text-xs tracking-widest leading-loose">
                Data submitted successfully
              </p>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12">
        {/* Entry Form */}
        <Card className="p-8 md:p-10 rounded-[40px] border-white/60 shadow-2xl relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-health-green/10 rounded-bl-[100px] -z-10"></div>
          
          <div className="flex justify-between items-center mb-10">
            <h3 className="text-2xl font-extrabold text-dark-text flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-trust-blue/10 flex items-center justify-center">
                <Calculator className="w-5 h-5 text-trust-blue" />
              </div>
              Child Assessment
            </h3>
          </div>

          <form onSubmit={calculateHealth} className="space-y-8">
            <div className="flex flex-col items-center gap-6 mb-4">
              <ProfileImageUpload 
                value={formData.avatar_url}
                onChange={(url) => setFormData({ ...formData, avatar_url: url })}
                fallbackSeed={formData.name}
              />
              <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Child Profile Photo</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Input
                label="👶 Child Name"
                placeholder="e.g. Rahul Kumar"
                icon={User}
                value={formData.name}
                error={errors.name}
                onChange={(e: any) => {
                  setFormData({ ...formData, name: e.target.value });
                  if (errors.name) setErrors({ ...errors, name: '' });
                }}
              />
              <div className="space-y-1.5">
                <label className="text-sm font-bold text-gray-600 ml-1">Gender</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setFormData({ ...formData, gender: 'Male' })}
                    className={`h-12 rounded-2xl font-bold text-sm transition-all flex items-center justify-center gap-2 border-2 ${
                      formData.gender === 'Male' 
                        ? 'bg-trust-blue shadow-lg shadow-trust-blue/20 border-trust-blue text-white' 
                        : 'bg-white border-gray-100 text-gray-400 hover:border-gray-200'
                    }`}
                  >
                    <span>Boy</span> 👦
                  </button>
                  <button
                    type="button"
                    onClick={() => setFormData({ ...formData, gender: 'Female' })}
                    className={`h-12 rounded-2xl font-bold text-sm transition-all flex items-center justify-center gap-2 border-2 ${
                      formData.gender === 'Female' 
                        ? 'bg-health-green shadow-lg shadow-health-green/20 border-health-green text-white' 
                        : 'bg-white border-gray-100 text-gray-400 hover:border-gray-200'
                    }`}
                  >
                    <span>Girl</span> 👧
                  </button>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Input
                label="🎂 Age (2-12)"
                type="number"
                placeholder="5"
                value={formData.age}
                error={errors.age}
                onChange={(e: any) => {
                  setFormData({ ...formData, age: e.target.value });
                  if (errors.age) setErrors({ ...errors, age: '' });
                }}
              />
              <Input
                label="📏 Height (cm)"
                type="number"
                placeholder="110"
                icon={Ruler}
                value={formData.height}
                error={errors.height}
                onChange={(e: any) => {
                  setFormData({ ...formData, height: e.target.value });
                  if (errors.height) setErrors({ ...errors, height: '' });
                }}
              />
              <Input
                label="⚖️ Weight (kg)"
                type="number"
                placeholder="20"
                icon={Weight}
                value={formData.weight}
                error={errors.weight}
                onChange={(e: any) => {
                  setFormData({ ...formData, weight: e.target.value });
                  if (errors.weight) setErrors({ ...errors, weight: '' });
                }}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Input
                 label="👨👩👧 Parent Name"
                 placeholder="Father or Mother"
                 icon={User}
                 value={formData.parent_name}
                 error={errors.parent_name}
                 onChange={(e: any) => {
                   setFormData({ ...formData, parent_name: e.target.value });
                   if (errors.parent_name) setErrors({ ...errors, parent_name: '' });
                 }}
              />
              <Input
                 label="📱 Mobile Number"
                 placeholder="10-digit number"
                 icon={Phone}
                 value={formData.contact}
                 error={errors.contact}
                 onChange={(e: any) => {
                   setFormData({ ...formData, contact: e.target.value });
                   if (errors.contact) setErrors({ ...errors, contact: '' });
                 }}
              />
            </div>

            <Button type="submit" className="w-full h-16 text-lg rounded-2xl mt-4 shadow-xl hover:shadow-trust-blue/20">
              Check Health Status
            </Button>
          </form>
        </Card>

        {/* Result & Suggestions */}
        <div className="space-y-8">
          <AnimatePresence mode="wait">
            {result ? (
              <motion.div
                key="result"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="space-y-8"
              >
                <Card className="p-10 border-white/60 shadow-2xl rounded-[40px] relative overflow-hidden">
                  <div 
                    className="absolute top-0 right-0 w-4 h-full opacity-20" 
                    style={{ backgroundColor: categoryData?.color }}
                  ></div>
                  
                  <div className="flex items-center justify-between mb-8">
                    <div>
                      <p className="text-[10px] font-extrabold uppercase tracking-[0.2em] text-gray-400 mb-1">Health Classification</p>
                      <h4 className="text-4xl font-extrabold tracking-tight" style={{ color: categoryData?.color }}>
                        {categoryData?.label} {categoryData?.icon}
                      </h4>
                    </div>
                    <div className="w-16 h-16 rounded-3xl bg-gray-50 border border-gray-100 flex flex-col items-center justify-center">
                       <span className="text-[10px] font-bold text-gray-400">BMI</span>
                       <span className="text-lg font-extrabold text-dark-text">{result.bmi}</span>
                    </div>
                  </div>

                  {result.heightWarning && (
                    <motion.div 
                      initial={{ x: -10, opacity: 0 }}
                      animate={{ x: 0, opacity: 1 }}
                      className="p-5 rounded-2xl bg-orange-50/50 text-orange-700 flex items-center gap-4 mb-8 border border-orange-100"
                    >
                      <div className="w-10 h-10 rounded-xl bg-orange-100 flex items-center justify-center flex-shrink-0">
                        <AlertCircle className="w-6 h-6" />
                      </div>
                      <p className="text-xs font-bold uppercase tracking-tight leading-relaxed">Warning: Growth parameters are deviant from norms!</p>
                    </motion.div>
                  )}

                  <div className="bg-gray-50/50 border border-gray-100 rounded-3xl p-8 mb-8">
                    <div className="w-full bg-gray-200/50 h-5 rounded-full overflow-hidden shadow-inner p-1">
                      <motion.div 
                        initial={{ width: 0 }}
                        animate={{ width: `${Math.min(100, (result.bmi / 30) * 100)}%` }}
                        transition={{ duration: 1.5, ease: "easeOut" }}
                        className="h-full rounded-full shadow-sm"
                        style={{ backgroundColor: categoryData?.color }}
                      />
                    </div>
                  </div>

                  <div className="flex gap-4">
                    <Button 
                      variant="outline" 
                      onClick={() => setResult(null)} 
                      className="flex-1 h-16 rounded-2xl border-gray-200 text-gray-500"
                    >
                      <ArrowLeft className="w-5 h-5 mr-2" />
                      Re-Check
                    </Button>
                    <Button 
                      onClick={saveRecord} 
                      className="flex-[2] h-16 rounded-2xl shadow-xl hover:shadow-health-green/20" 
                      disabled={loading}
                    >
                      {loading ? 'Transmitting...' : 'Submit Health Data'}
                      <Send className="w-5 h-5 ml-2" />
                    </Button>
                  </div>
                </Card>

                <Card className="p-10 border-white/60 shadow-2xl rounded-[40px] bg-white/80 backdrop-blur-sm">
                  <h4 className="text-xl font-extrabold text-dark-text mb-8 flex items-center gap-2">
                    <div className="w-2 h-6 bg-health-green rounded-full"></div>
                    Nutritional Interventions
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {categoryData?.suggestions.map((item: any, i: number) => (
                      <motion.div 
                        key={i} 
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: i * 0.1 }}
                        className="flex items-center gap-4 p-5 bg-white rounded-3xl border border-gray-100 shadow-sm hover:shadow-md transition-all group"
                      >
                        <span className="text-3xl group-hover:scale-125 transition-transform">{item.emoji}</span>
                        <span className="font-bold text-gray-600 text-sm">{item.food}</span>
                      </motion.div>
                    ))}
                  </div>
                </Card>
              </motion.div>
            ) : (
              <motion.div 
                key="empty"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="h-full flex flex-col items-center justify-center text-center p-12 bg-white/40 border-4 border-dashed border-gray-200/50 rounded-[48px] relative overflow-hidden group min-h-[500px]"
              >
                <div className="absolute inset-0 bg-gradient-to-br from-trust-blue/5 via-transparent to-health-green/5 opacity-0 group-hover:opacity-100 transition-opacity duration-700"></div>
                <motion.div 
                  animate={{ y: [0, -10, 0] }}
                  transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
                  className="w-32 h-32 bg-white rounded-[40px] flex items-center justify-center text-5xl mb-8 shadow-2xl shadow-gray-200 relative z-10"
                >
                  🥗
                </motion.div>
                <h4 className="text-3xl font-extrabold text-dark-text mb-4 z-10 tracking-tight italic">Ready for Assessment</h4>
                <p className="text-gray-400 max-w-sm z-10 font-bold uppercase text-[10px] tracking-widest leading-loose opacity-60">
                  Input biometric markers to generate medical-grade health insights
                </p>
                <div className="mt-12 flex gap-3 z-10">
                   <div className="w-2 h-2 rounded-full bg-trust-blue shadow-lg shadow-trust-blue/40"></div>
                   <div className="w-2 h-2 rounded-full bg-health-green shadow-lg shadow-health-green/40"></div>
                   <div className="w-2 h-2 rounded-full bg-energy-orange shadow-lg shadow-energy-orange/40"></div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
};
