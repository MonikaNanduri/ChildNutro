import { useEffect, useState } from 'react';
import { Users, Heart, AlertTriangle, CheckCircle, TrendingUp, RefreshCw } from 'lucide-react';
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Legend } from 'recharts';
import { Card } from '../components/ui/Common';
import { api } from '../lib/api';
import { offlineDb } from '../lib/offlineDb';
import { DashboardStats } from '../types';
import { translations, Language } from '../lib/translations';

export const Dashboard = () => {
  const [data, setData] = useState<{ stats: DashboardStats; recentEntries: any[] } | null>(null);
  const [pendingEntries, setPendingEntries] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [currentLang, setCurrentLang] = useState<Language>(() => {
    const user = JSON.parse(localStorage.getItem('user') || '{}');
    return (user.language as Language) || 'English';
  });
  
  const t = translations[currentLang] || translations.English;

  const fetchData = async () => {
    try {
      const dashboard = await api.getDashboardData();
      setData(dashboard);
      
      const pending = await offlineDb.getAllRequests();
      const relevantPending = pending.filter(r => r.type === 'fullChildRecord' || r.type === 'addNutrition');
      setPendingEntries(relevantPending.map(p => ({
        id: -1,
        name: p.type === 'fullChildRecord' ? p.data.childData.name : 'Unknown',
        bmi: p.type === 'fullChildRecord' ? p.data.nutritionData.bmi : p.data.bmi,
        status: p.type === 'fullChildRecord' ? p.data.nutritionData.status : p.data.status,
        recorded_at: p.timestamp,
        isPending: true
      })));
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
    window.addEventListener('syncComplete', fetchData);
    
    const handleLangChange = () => {
      const user = JSON.parse(localStorage.getItem('user') || '{}');
      setCurrentLang((user.language as Language) || 'English');
    };
    
    window.addEventListener('languageChange', handleLangChange);
    return () => {
      window.removeEventListener('languageChange', handleLangChange);
      window.removeEventListener('syncComplete', fetchData);
    };
  }, []);

  if (loading) return <div className="flex items-center justify-center h-64">Loading statistics...</div>;

  const combinedEntries = [...pendingEntries, ...(data?.recentEntries || [])].slice(0, 5);

  const chartData = [
    { name: 'Normal', value: data?.stats?.normal || 0, color: '#6BCB77' },
    { name: 'Underweight', value: data?.stats?.underweight || 0, color: '#FFD93D' },
    { name: 'Overweight', value: data?.stats?.overweight || 0, color: '#FF6B6B' },
  ];

  const stats = [
    { label: t.totalChildren, value: data?.stats?.total || 0, icon: Users, color: 'blue', bg: 'bg-blue-50' },
    { label: t.normalStatus, value: data?.stats?.normal || 0, icon: CheckCircle, color: 'green', bg: 'bg-green-50' },
    { label: 'Underweight', value: data?.stats?.underweight || 0, icon: AlertTriangle, color: 'yellow', bg: 'bg-yellow-50' },
    { label: 'Overweight', value: data?.stats?.overweight || 0, icon: AlertTriangle, color: 'red', bg: 'bg-red-50' },
  ];

  return (
    <div className="space-y-8">
      {/* Stats Summary */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, i) => (
          <Card key={i} delay={i * 0.1} className="overflow-hidden group hover:scale-[1.02] transition-transform">
            <div className="flex items-center justify-between relative">
              <div className="z-10">
                <p className="text-gray-500 text-[10px] font-bold uppercase tracking-widest">{stat.label}</p>
                <h3 className="text-3xl font-extrabold mt-1 text-dark-text tracking-tight">{stat.value}</h3>
              </div>
              <div className={`p-4 rounded-2xl ${stat.bg} shadow-sm group-hover:shadow-md transition-shadow relative overflow-hidden flex items-center justify-center w-14 h-14`}>
                <div className={`absolute inset-0 opacity-10 bg-gradient-to-br from-white to-transparent`}></div>
                <stat.icon className={`w-7 h-7 text-${stat.color}-500 relative z-10`} />
              </div>
            </div>
            {/* Subtle progress bar or indicator at bottom */}
            <div className="absolute bottom-0 left-0 h-1 bg-gradient-to-r from-transparent via-current to-transparent opacity-10 w-full" style={{ color: stat.color }}></div>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Growth Trends Chart */}
        <Card className="lg:col-span-2 p-8" delay={0.4}>
          <div className="flex items-center justify-between mb-8">
            <h3 className="text-xl font-bold flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-trust-blue/20 flex items-center justify-center">
                <TrendingUp className="w-4 h-4 text-trust-blue" />
              </div>
              {t.overview}
            </h3>
            <div className="flex gap-2">
              <span className="flex items-center gap-1.5 text-[10px] font-bold text-gray-400">
                <div className="w-2 h-2 rounded-full bg-health-green"></div> NORMAL
              </span>
              <span className="flex items-center gap-1.5 text-[10px] font-bold text-gray-400">
                <div className="w-2 h-2 rounded-full bg-energy-orange"></div> RISK
              </span>
            </div>
          </div>
          <div className="h-80 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData}>
                <XAxis 
                  dataKey="name" 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fontSize: 10, fontWeight: 700, fill: '#666' }} 
                />
                <YAxis 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fontSize: 10, fontWeight: 700, fill: '#666' }} 
                />
                <Tooltip 
                  cursor={{ fill: 'transparent' }} 
                  contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 25px rgba(0,0,0,0.1)' }}
                />
                <Bar dataKey="value" radius={[6, 6, 0, 0]} barSize={40}>
                  {chartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>

        {/* Nutrition Distribution */}
        <Card className="p-8" delay={0.5}>
          <h3 className="text-xl font-bold mb-8">Distribution</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={chartData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={8}
                  dataKey="value"
                  stroke="none"
                >
                  {chartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip 
                   contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 25px rgba(0,0,0,0.1)' }}
                />
                <Legend 
                  iconType="circle" 
                  verticalAlign="bottom" 
                  formatter={(value) => <span className="text-[10px] font-bold text-gray-500 uppercase">{value}</span>}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </Card>
      </div>

      {/* Recent Entries */}
      <Card className="p-8" delay={0.6}>
        <div className="flex items-center justify-between mb-8">
          <h3 className="text-xl font-bold">{t.recentRegistrations}</h3>
          <button className="text-[10px] uppercase font-bold tracking-widest text-trust-blue border-b-2 border-trust-blue/20 hover:border-trust-blue transition-colors">{t.records}</button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="text-left text-[11px] font-bold text-gray-400 uppercase tracking-widest border-b border-gray-100">
                <th className="pb-4">Identification</th>
                <th className="pb-4">BMI Index</th>
                <th className="pb-4">Health Status</th>
                <th className="pb-4">Logged On</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {combinedEntries.map((entry, i) => (
                <tr key={i} className="hover:bg-gray-50/50 transition-all group">
                  <td className="py-5">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-gray-50 to-gray-200 p-0.5 shadow-sm group-hover:shadow-md transition-shadow relative">
                        <div className="w-full h-full rounded-[10px] bg-white flex items-center justify-center overflow-hidden">
                           <img 
                            src={`https://api.dicebear.com/7.x/avataaars/svg?seed=child_${entry.id === -1 ? entry.name : entry.id}`} 
                            alt={entry.name} 
                            className="w-full h-full object-cover scale-110"
                           />
                        </div>
                        {entry.isPending && (
                          <div className="absolute -top-1 -right-1 w-4 h-4 bg-trust-blue text-white rounded-full flex items-center justify-center shadow-md">
                            <RefreshCw className="w-2 h-2 animate-spin" />
                          </div>
                        )}
                      </div>
                      <div>
                        <p className="font-bold text-sm text-dark-text flex items-center gap-2">
                          {entry.name}
                          {entry.isPending && <span className="text-[6px] font-bold px-1 py-0.5 bg-trust-blue/10 text-trust-blue rounded uppercase tracking-tighter">Syncing</span>}
                        </p>
                        <p className="text-[10px] font-bold text-gray-400 uppercase tracking-tight">
                          {entry.isPending ? 'Pending Upload' : `Record #${entry.id}`}
                        </p>
                      </div>
                    </div>
                  </td>
                  <td className="py-5">
                    <div className="flex flex-col">
                      <span className="font-bold text-sm text-dark-text">{entry.bmi}</span>
                      <div className="w-16 h-1 bg-gray-100 rounded-full mt-1.5 overflow-hidden">
                        <div 
                          className={`h-full rounded-full ${
                            entry.status === 'Normal' ? 'bg-health-green' : 
                            entry.status === 'Underweight' ? 'bg-energy-orange' : 'bg-red-400'
                          }`}
                          style={{ width: `${Math.min((parseFloat(entry.bmi) / 30) * 100, 100)}%` }}
                        ></div>
                      </div>
                    </div>
                  </td>
                  <td className="py-5">
                    <span className={`px-3 py-1.5 rounded-lg text-[10px] font-extrabold uppercase tracking-widest ${
                      entry.status === 'Normal' ? 'bg-health-green/10 text-health-green border border-health-green/20' :
                      entry.status === 'Underweight' ? 'bg-energy-orange/10 text-energy-orange border border-energy-orange/20' :
                      'bg-red-50 text-red-600 border border-red-100'
                    }`}>
                      {entry.status}
                    </span>
                  </td>
                  <td className="py-5">
                    <div className="flex flex-col">
                      <span className="text-xs font-bold text-dark-text/70">
                        {new Date(entry.recorded_at).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })}
                      </span>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
};
