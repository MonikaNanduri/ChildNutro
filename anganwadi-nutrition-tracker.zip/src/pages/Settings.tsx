import { useState, useEffect } from 'react';
import { User, Languages, Globe, Mail, Loader2, Save, Phone } from 'lucide-react';
import { Card, Button, Input } from '../components/ui/Common';
import { ProfileImageUpload } from '../components/ui/ProfileImageUpload';
import { api } from '../lib/api';

export const Settings = () => {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [profile, setProfile] = useState<any>(null);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    center_name: '',
    center_code: '',
    region: '',
    language: 'English',
    avatar_url: ''
  });

  const [offlineEnabled, setOfflineEnabled] = useState(true);

  const fetchProfile = async () => {
    try {
      setLoading(true);
      const data = await api.getProfile();
      setProfile(data);
      setFormData({
        name: data.name || '',
        email: data.email || '',
        phone: data.phone || '',
        center_name: data.center_name || '',
        center_code: data.center_code || '',
        region: data.region || 'Mumbai',
        language: data.language || 'English',
        avatar_url: data.avatar_url || ''
      });
    } catch (error) {
      console.error(error);
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      window.location.reload();
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProfile();
  }, []);

  const handleSave = async () => {
    try {
      setSaving(true);
      await api.updateProfile(formData);
      const user = JSON.parse(localStorage.getItem('user') || '{}');
      localStorage.setItem('user', JSON.stringify({ 
        ...user, 
        ...formData
      }));
      alert('Settings saved successfully! ✨');
    } catch (error) {
      alert('Failed to save settings.');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center p-20 gap-4">
        <Loader2 className="w-10 h-10 text-trust-blue animate-spin" />
        <p className="font-bold text-dark-text/60">Loading Your Preferences...</p>
      </div>
    );
  }

  return (
    <div className="max-w-4xl space-y-8 pb-20">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <Card className="md:col-span-1 p-8 text-center flex flex-col items-center justify-start min-h-[350px] relative">
            <ProfileImageUpload 
              value={formData.avatar_url}
              onChange={(url) => setFormData({ ...formData, avatar_url: url })}
              fallbackSeed={profile?.username}
              className="mb-6 scale-125 origin-top"
            />
            <h3 className="text-xl font-bold mt-2">{formData.name}</h3>
            <p className="text-gray-500 text-sm font-medium">Worker ID: #0{profile?.id}</p>
            <div className="mt-8 p-4 bg-gray-50 rounded-2xl w-full border border-gray-100 italic text-[10px] text-gray-400 font-bold uppercase tracking-wider">
               Status: Fully Synchronized
            </div>
        </Card>

        <Card className="md:col-span-2 p-8">
          <h4 className="text-lg font-bold mb-8 flex items-center gap-3">
             <div className="w-8 h-8 rounded-lg bg-trust-blue/20 flex items-center justify-center">
               <User className="w-4 h-4 text-trust-blue" />
             </div>
             Personal Information
          </h4>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
             <Input 
                label="Full Name" 
                value={formData.name} 
                onChange={(e: any) => setFormData({ ...formData, name: e.target.value })}
             />
             <Input 
                label="Registered Username" 
                value={profile?.username} 
                readOnly 
                className="bg-gray-50 cursor-not-allowed"
             />
             <Input 
                label="Email Address" 
                placeholder="worker@government.in" 
                icon={Mail}
                value={formData.email}
                onChange={(e: any) => setFormData({ ...formData, email: e.target.value })}
             />
             <Input 
                label="Mobile Number" 
                placeholder="+91 98765 43210" 
                icon={Phone}
                value={formData.phone}
                onChange={(e: any) => setFormData({ ...formData, phone: e.target.value })}
             />
          </div>
          <Button 
              className="mt-8 w-full sm:w-auto px-8"
              onClick={handleSave}
              disabled={saving}
          >
            {saving ? <Loader2 className="w-5 h-5 animate-spin" /> : <Save className="w-5 h-5 mr-2" />}
            {saving ? 'Saviing...' : 'Save All Changes'}
          </Button>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
         <Card className="p-8">
            <h4 className="text-lg font-bold mb-8 flex items-center gap-3">
               <div className="w-8 h-8 rounded-lg bg-health-green/20 flex items-center justify-center">
                  <Languages className="w-4 h-4 text-health-green" />
               </div>
               Language Selection
            </h4>
            <div className="space-y-3">
               {['English', 'Hindi', 'Marathi', 'Telugu', 'Bengali', 'Tamil', 'Gujarati', 'Kannada', 'Odia', 'Malayalam'].map((lang) => (
                  <button 
                    key={lang}
                    onClick={() => setFormData({ ...formData, language: lang })}
                    className={`w-full flex items-center justify-between p-4 rounded-xl border-2 transition-all group ${
                      formData.language === lang 
                        ? 'border-trust-blue bg-trust-blue/5 shadow-sm' 
                        : 'border-gray-100 hover:border-gray-200'
                    }`}
                  >
                     <span className={`font-bold text-sm ${formData.language === lang ? 'text-trust-blue' : 'text-dark-text/70'}`}>
                       {lang}
                     </span>
                     {formData.language === lang && (
                       <div className="w-5 h-5 rounded-full bg-trust-blue flex items-center justify-center scale-110 shadow-sm">
                         <div className="w-2 h-2 bg-white rounded-full"></div>
                       </div>
                     )}
                  </button>
               ))}
            </div>
         </Card>

         <Card className="p-8">
            <h4 className="text-lg font-bold mb-8 flex items-center gap-3">
               <div className="w-8 h-8 rounded-lg bg-energy-orange/20 flex items-center justify-center">
                 <Globe className="w-4 h-4 text-energy-orange" />
               </div>
               Regional Details
            </h4>
            <div className="space-y-6">
               <Input 
                  label="Anganwadi Center Name" 
                  placeholder="e.g. Central Mumbai Branch A" 
                  value={formData.center_name}
                  onChange={(e: any) => setFormData({ ...formData, center_name: e.target.value })}
               />
               <Input 
                  label="Center Code" 
                  placeholder="AW-400012" 
                  value={formData.center_code}
                  onChange={(e: any) => setFormData({ ...formData, center_code: e.target.value })}
               />
               <Input 
                  label="District / Region" 
                  placeholder="e.g. Mumbai" 
                  value={formData.region}
                  onChange={(e: any) => setFormData({ ...formData, region: e.target.value })}
               />
               <div className="pt-6 border-t border-dark-text/5">
                  <div className="flex items-center justify-between mb-4">
                     <div>
                        <h5 className="font-bold text-sm text-dark-text">Offline Sync</h5>
                        <p className="text-[10px] uppercase font-bold text-dark-text/40 tracking-wider">Save data without internet</p>
                     </div>
                     <button 
                        onClick={() => setOfflineEnabled(!offlineEnabled)}
                        className={`w-12 h-7 rounded-full relative shadow-inner p-1 transition-colors ${offlineEnabled ? 'bg-health-green' : 'bg-gray-200'}`}
                     >
                        <div className={`absolute top-1 w-5 h-5 bg-white rounded-full shadow-sm transition-all ${offlineEnabled ? 'right-1' : 'left-1'}`}></div>
                     </button>
                  </div>
                  <div className="p-4 bg-health-green/10 rounded-2xl border border-health-green/20">
                    <p className="text-[10px] font-bold text-health-green uppercase tracking-widest mb-1 text-center">Safety Protocol Enabled</p>
                    <p className="text-[11px] font-bold text-dark-text/40 text-center uppercase tracking-tight">Enabled by default to ensure no data loss in poor connectivity areas.</p>
                  </div>
               </div>
            </div>
         </Card>
      </div>
    </div>
  );
};
